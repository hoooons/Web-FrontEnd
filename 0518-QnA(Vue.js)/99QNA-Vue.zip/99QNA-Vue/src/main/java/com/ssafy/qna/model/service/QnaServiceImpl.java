package com.ssafy.qna.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.qna.model.dto.Qna;
import com.ssafy.qna.model.mapper.QnaMapper;

@Service
public class QnaServiceImpl implements QnaService {

	@Autowired
	QnaMapper mapper;
	
	@Override
	public List<Qna> selectAll() {
		return mapper.selectAll();
	}

	@Override
	public void insertQna(Qna qna) {
		mapper.insertQna(qna);
	}

	@Override
	public void deleteQna(int id) {
		mapper.deleteQna(id);
	}

	@Override
	public void updateQna(Qna qna) {
		mapper.updateQna(qna);
	}

	@Override
	public Qna detail(int id) {
		return mapper.detail(id);
	}
}
