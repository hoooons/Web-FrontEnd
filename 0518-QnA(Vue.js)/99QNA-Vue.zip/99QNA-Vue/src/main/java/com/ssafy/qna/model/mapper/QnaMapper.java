package com.ssafy.qna.model.mapper;

import java.util.List;

import com.ssafy.qna.model.dto.Qna;

public interface QnaMapper {
	List<Qna> selectAll();
	void insertQna(Qna qna);
	void deleteQna(int id);
	void updateQna(Qna qna);
	Qna detail(int id);	
}
