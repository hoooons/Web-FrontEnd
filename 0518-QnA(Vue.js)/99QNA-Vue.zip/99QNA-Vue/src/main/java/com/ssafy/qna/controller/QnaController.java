package com.ssafy.qna.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.qna.model.dto.Qna;
import com.ssafy.qna.model.service.QnaService;


@RestController
@CrossOrigin(origins = {"*"}, maxAge = 6000)
public class QnaController {

	private static final String SUCCESS = "success";
	
	@Autowired
	QnaService service;
	
	@GetMapping("/qna/all")
	public List<Qna> selectAll() throws Exception{
		List<Qna> list = service.selectAll();
		return list;
	}
	
	@PostMapping("/qna/insert")
	public List<Qna> insertQna(@RequestBody Qna qna){
		service.insertQna(qna);
		return service.selectAll();
	}
	
	@PutMapping("/qna/update")
	public List<Qna> updateTodo(@RequestBody Qna qna){
		service.updateQna(qna);
		return service.selectAll();
	}
	
	@DeleteMapping("/qna/delete/{id}")
	public List<Qna> deleteTodo(@PathVariable int id){
		service.deleteQna(id);
		return service.selectAll();
	}
	
	@GetMapping("/qna/detail/{id}")
	public Qna detail(@PathVariable int id) {
		return service.detail(id);
	}
}
