package com.ssafy.qna.model.service;

import java.util.List;

import com.ssafy.qna.model.dto.Qna;

public interface QnaService {

	List<Qna> selectAll();
	void insertQna(Qna qna);
	void deleteQna(int id);
	void updateQna(Qna qna);
	Qna detail(int id);	
	
}
